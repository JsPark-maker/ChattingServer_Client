﻿#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#include "framework.h"
#include "ChattingServer.h"
#include "CRingBuffer.h"
#include "PacketDefine.h"
#define MAX_LOADSTRING 100
#define SERVERPORT 9000
#define SERVERIP L"127.0.0.1"
#define WM_MESSAGE (WM_USER + 1)

HINSTANCE hInst;                                // 현재 인스턴스입니다.
WCHAR szTitle[MAX_LOADSTRING];                  // 제목 표시줄 텍스트입니다.
WCHAR szWindowClass[MAX_LOADSTRING];            // 기본 창 클래스 이름입니다.

// 이 코드 모듈에 포함된 함수의 선언을 전달합니다:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK    EditSubProc(HWND, UINT, WPARAM, LPARAM);
BOOL    CALLBACK    DlgProc(HWND, UINT, WPARAM, LPARAM);

WCHAR g_ServerIp[20];
WCHAR g_NickName[20];

//현재 접속자들을 모아놓은 전역리스트입니다.
stCLIENT* g_ClientList;
//서버에서 부여해준 나의 id이다.
int g_ID;

SOCKET g_ClientSock;
HWND g_hWnd;
CRingBuffer recvQueue;
CRingBuffer sendQueue;
bool g_SendFlag = true;
bool g_FirstConnect = true;

//수신
void ReadEvent();
//송신
void WriteEvent();
//송신링버퍼에 인큐잉하고 WriteEvent호출함수
void Send(stHEADER*, char*);
//데이터의 크기 알아내는함수
int  HowManyBytes(char*);
//서버 재연결 함수 추후에
bool ConnectWithServer();
//리스트박스의 포커스를 최신으로 맞춰주는 함수 -> 송신과 수신부분에 존재함
void SetListBoxFocus(HWND hWnd);

void SelectClientIdProc(stHEADER* header, stPACKET_CLIENT_ID*);

void CreateUserProc(stHEADER* header, stPACKET_CREATE_USER* packet);

void MessageProc(stHEADER* header, stPACKET_MESSAGE* packet);

void DeleteUserProc(stHEADER* header, stPACKET_DELETE_USER* packet);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_CHATTINGSERVER, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    if (!InitInstance (hInstance, nCmdShow))
    {
        return FALSE;
    }
    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_CHATTINGSERVER));
    MSG msg;

    AllocConsole();///////////////////////////
    freopen("CONOUT$", "wt", stdout);///////// 콘솔띄워주는부분

    DialogBox(hInst, MAKEINTRESOURCE(IDD_DIALOG1), g_hWnd, DlgProc);
    printf("클라이언트가동\n");//////////////////

    //리스트의 머리부분을 동적할당합니다.
    g_ClientList = new stCLIENT;

    int retVal;

    WSADATA wsa;

    WSAStartup(MAKEWORD(2, 2), &wsa);

    g_ClientSock = socket(AF_INET, SOCK_STREAM, NULL);

    WSAAsyncSelect(g_ClientSock, g_hWnd, WM_MESSAGE, FD_CONNECT | FD_READ | FD_WRITE);

    SOCKADDR_IN clientAddr;
    clientAddr.sin_family = AF_INET;
    clientAddr.sin_port = htons(SERVERPORT);
    InetPton(AF_INET, g_ServerIp, &clientAddr.sin_addr);

    retVal = connect(g_ClientSock, (SOCKADDR*)&clientAddr, sizeof(clientAddr));

    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    return (int) msg.wParam;
}

ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_CHATTINGSERVER));
    wcex.hCursor        = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = MAKEINTRESOURCEW(IDC_CHATTINGSERVER);
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // 인스턴스 핸들을 전역 변수에 저장합니다.

   g_hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, 400, 600, nullptr, nullptr, hInstance, nullptr);
   //400자리 Width 500자리 height

   if (!g_hWnd)
   {
      return FALSE;
   }

   ShowWindow(g_hWnd, nCmdShow);
   UpdateWindow(g_hWnd);

   return TRUE;
}

#define SENDBUTTONCLICK 0
#define EDITBOX         1
#define LISTBOX         2
static HWND hEdit;
static HWND hList;
static WNDPROC EditProc;
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_CREATE:
        //버튼
        CreateWindow(L"button", L"보내기", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        220, 420, 90, 25, hWnd, (HMENU)SENDBUTTONCLICK, hInst, NULL);
        //에디트윈도우 -> 글씨 쓰는곳
        hEdit = CreateWindow(L"edit", NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL | ES_WANTRETURN,
        10, 420, 200, 25, hWnd, (HMENU)EDITBOX, hInst, NULL);
        //GetWindowText를 통해서 문자열을 가져온다.
        //쓰일지는 모르겠으니 SetWindowText를 통해 윈도우에 글씨를 지정해줄수있다.
        //SetWindowText는 안쓸것같음

        hList = CreateWindow(L"listbox", NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_DISABLENOSCROLL | WS_VSCROLL,
            10, 10, 300, 400, hWnd, (HMENU)LISTBOX, hInst, NULL);
        
        EditProc = (WNDPROC)SetWindowLongPtr(hEdit, GWL_WNDPROC, (LONG)EditSubProc);
        break;
    case WM_LBUTTONDOWN:
        break;
    case WM_MESSAGE:
        if (WSAGETSELECTERROR(lParam))
        {
            printf("에러가 발생\n");
            closesocket(g_ClientSock);
        }
        else
        {
            switch (WSAGETSELECTEVENT(lParam))
            {
                //이 부분에서 내가 입력한 닉네임을 보내준다.
            case FD_CONNECT:
            {
                stHEADER header;
                header.type = dfPACKET_CONNECT_USER;
                header.len = HowManyBytes((char*)g_NickName);
                Send(&header, (char*)g_NickName);
            }
            break;
            case FD_READ: //수신버퍼에 데이터가 들어있따
                printf("FD_READ\n");
                ReadEvent();
                break;
            case FD_WRITE: //송신버퍼가 찼었는데 이제 비워져서 보낼구멍이 생겼다.
                printf("FD_WRITE\n");
                g_SendFlag = true;
                WriteEvent();
                break;
            }
        }
        break;
    case WM_COMMAND:
        {
            int wmId = LOWORD(wParam);
            // 메뉴 선택을 구문 분석합니다:
            switch (wmId)
            {
            case SENDBUTTONCLICK:
                //WCHAR myMessage[128];
                stPACKET_MESSAGE myMessage;
                myMessage.id = g_ID;
                GetWindowText(hEdit, myMessage.packet, 128);
                //SendMessage(hList, LB_ADDSTRING, 0, (LPARAM)myMessage);
                SetWindowText(hEdit, L"");
                stHEADER header;
                header.type = dfPACKET_MESSAGE;
                header.len = HowManyBytes((char*)myMessage.packet) + sizeof(myMessage.id);
                Send(&header, (char*)&myMessage);
                break;
            case EDITBOX:
                break;
            case LISTBOX:
                switch (HIWORD(wParam))
                {
                case LBN_DBLCLK:
                    printf("더블클릭\n");
                    break;
                case LBN_SELCHANGE:
                    printf("항목중 하나 선택\n");
                    break;
                case LBN_SETFOCUS:
                    printf("포커스를 받음\n");
                    break;
                case LBN_KILLFOCUS:
                    printf("포커스를 잃음\n");
                    break;
                }
                break;
            case IDM_EXIT:
                DestroyWindow(hWnd);
                break;
            default:
                return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }
        break;
    case WM_PAINT:
        {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);
            // TODO: 여기에 hdc를 사용하는 그리기 코드를 추가합니다...
            EndPaint(hWnd, &ps);
        }
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

void ReadEvent()
{
    int recvBytes;
    int enqueueBytes;

    char buffer[1000];

    recvBytes = recv(g_ClientSock, buffer, 1000, NULL);

    //서버에서 종료했을경우 0 , 우드블락일경우 소켓에러 socket_error일경우 우드블락이면 다 뽑은것이므로 리턴때려야함 만 약 다른 에러라면 그냥 죽이기
    if (recvBytes == SOCKET_ERROR)
    {
        if (WSAGetLastError() != WSAEWOULDBLOCK)
        {
            closesocket(g_ClientSock);
            printf("ReadEvent()에서 소켓에러가 떴습니다.\n");
            return;
        }
    }
    if (recvBytes == 0)
    {
        printf("상대측이 연결을 종료했습니다.\n");
        return;
    }

    printf("%d 만큼 받았습니다.\n", recvBytes);

    enqueueBytes = recvQueue.Enqueue(buffer, recvBytes);
    if (enqueueBytes != recvBytes)
    {
        printf("모든 데이터가 링버퍼에 들어가지않았습니다 접속을 종료합니다.\n");
        closesocket(g_ClientSock);
        return;
    }

    while (1)
    {
        stHEADER header;
        char packet[1000];
        if (recvQueue.GetUseSize() < sizeof(header))
        {
            break;
        }

        recvQueue.Peek((char*)&header, sizeof(header));

        if (recvQueue.GetUseSize() - sizeof(header) < header.len)
        {
            printf("아직 헤더에서 명시한양의 데이터가 존재하지않습니다.");
            break;
        }
        
        recvQueue.MoveFront(sizeof(header));
        recvQueue.Dequeue((char*)&packet, header.len);

        switch (header.type)
        {
        case dfPACKET_CLIENT_ID:
            SelectClientIdProc(&header, (stPACKET_CLIENT_ID*)packet);
            break;
        case dfPACKET_CREATE_USER:
            CreateUserProc(&header, (stPACKET_CREATE_USER*)packet);
            break;
        case dfPACKET_MESSAGE:
            MessageProc(&header, (stPACKET_MESSAGE*)packet);
            break;
        case dfPACKET_DELETE_USER:
            DeleteUserProc(&header, (stPACKET_DELETE_USER*)packet);
            break;
        }
    }
}

void SelectClientIdProc(stHEADER* header, stPACKET_CLIENT_ID* packet)
{
    g_ID = packet->id;
}

void CreateUserProc(stHEADER* header, stPACKET_CREATE_USER* packet)
{
    for (stCLIENT* clientList = g_ClientList;; clientList = clientList->next)
    {
        if (clientList->next != nullptr)
            continue;

        stCLIENT* newClient = new stCLIENT;
        newClient->id = packet->id;
        wcscpy(newClient->nickName, packet->userNickName);
        newClient->prev = clientList;
        clientList->next = newClient;

        //if (g_FirstConnect == false)
        {
            WCHAR messageBuffer[64];

            wsprintfW(messageBuffer, L"< %s 님이 참여했습니다. >", newClient->nickName);

            SendMessage(hList, LB_ADDSTRING, NULL, (LPARAM)messageBuffer);
            SendMessage(hList, LB_ADDSTRING, NULL, (LPARAM)L"");
        }

        break;
    }

}

void MessageProc(stHEADER* header, stPACKET_MESSAGE* packet)
{
    //packet->packet[(header->len - sizeof(packet->id)) / 2] = '\0';
    WCHAR nickNameBuffer[128];
    for (stCLIENT* clientList = g_ClientList->next;; clientList = clientList->next)
    {
        if (clientList == nullptr)
            break;

        if (clientList->id != packet->id)
            continue;


        wcscpy(nickNameBuffer, clientList->nickName);
        int len = wcslen(nickNameBuffer);

        nickNameBuffer[len] = ':';
        nickNameBuffer[len + 1] = '\0';


        SendMessage(hList, LB_ADDSTRING, 0, (LPARAM)nickNameBuffer);
        break;
    }

    SendMessage(hList, LB_ADDSTRING, 0, (LPARAM)packet->packet);
    SendMessage(hList, LB_ADDSTRING, 0, (LPARAM)L"");

    SetListBoxFocus(hList);
}

void DeleteUserProc(stHEADER* header, stPACKET_DELETE_USER* packet)
{
    for (stCLIENT* clientList = g_ClientList;; clientList = clientList->next)
    {
        if (clientList->id != packet->id)
            continue;

        if (clientList->next == nullptr)
        {
            clientList->prev->next = nullptr;
        }
        else
        {
            clientList->next->prev = clientList->prev;
            clientList->prev->next = clientList->next;
        }

        delete clientList;
        break;
    }
}

void WriteEvent()
{
    int dequeueBytes;
    int sendBytes;
    char buffer[1000];
    while (1)
    {
        if (sendQueue.GetUseSize() == 0)
        {
            return;
        }
        dequeueBytes = sendQueue.Peek(buffer, sizeof(buffer));

        sendBytes = send(g_ClientSock, buffer, dequeueBytes, NULL);

        if (sendBytes == SOCKET_ERROR)
        {
            if (WSAGetLastError() == WSAEWOULDBLOCK)
            {
                printf("송신버퍼가 가득찼습니다.\n");
                return;
            }
            
        }

        if (sendBytes == SOCKET_ERROR)
        {
            if (WSAGetLastError() == WSAEWOULDBLOCK)
            {
                printf("현재 송신버퍼가 가득찼습니다. WriteEvent를 종료합니다.\n");
                g_SendFlag = false;
                sendQueue.MoveFront(sendBytes);
                return;
            }
            else
            {
                SendMessage(hList, LB_ADDSTRING, 0, (LPARAM)L"서버랑 연결되지않았습니다. 다시 실행해주십시오.\n");
                SetListBoxFocus(hList);
                return;
            }
        }

        SetListBoxFocus(hList);

        printf("%d바이트만큼 보냈습니다.\n", sendBytes);

        sendQueue.MoveFront(sendBytes);
    }
}

void Send(stHEADER* header,char* data)
{
    printf("Send\n");
    int enqueueBytes;

    enqueueBytes = sendQueue.Enqueue((char*)header, sizeof(stHEADER));
    if (enqueueBytes != sizeof(stHEADER))
    {
        printf("sendQueue에 인큐가 안됬습니다. 연결을 종료합니다.\n");
        closesocket(g_ClientSock);
        return;
    }
    enqueueBytes = sendQueue.Enqueue(data, header->len);
    if (enqueueBytes != header->len)
    {
        printf("sendQueue에 인큐가 안됬습니다. 연결을 종료합니다.\n");
        closesocket(g_ClientSock);
        return;
    }
    if (g_SendFlag == true)
    {
        WriteEvent();
    }
}

int HowManyBytes(char* data)
{
    int retVal = wcslen((WCHAR*)data) * 2 + 2;
    return retVal;
}

void SetListBoxFocus(HWND hWnd)
{
    int num = SendMessage(hWnd, LB_GETCOUNT, NULL, NULL);
    int retVal = SendMessage(hWnd, LB_SETCARETINDEX, num - 1, NULL);
}

LRESULT CALLBACK EditSubProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
    switch (iMessage)
    {
    case WM_KEYDOWN:
        switch (wParam)
        {
            //엔터키
        case VK_RETURN:
            //WCHAR myMessage[128];
            stPACKET_MESSAGE myMessage;
            myMessage.id = g_ID;
            GetWindowText(hEdit, myMessage.packet, 128);
            //SendMessage(hList, LB_ADDSTRING, 0, (LPARAM)myMessage);
            SetWindowText(hEdit, L"");
            stHEADER header;
            header.type = dfPACKET_MESSAGE;
            header.len = HowManyBytes((char*)myMessage.packet) + sizeof(myMessage.id);
            Send(&header, (char*)&myMessage);
            break;
        }
        break;
    }

    return CallWindowProc(EditProc, hWnd, iMessage, wParam, lParam);
}

BOOL CALLBACK DlgProc(HWND hDlg, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
    switch (iMessage)
    {
    case WM_INITDIALOG:
        //초기화 코드를 작성하면된다.
        return true;
    case WM_COMMAND:
        switch (wParam)
        {
        case IDOK:
            GetDlgItemText(hDlg, IDC_EDIT1, g_ServerIp, _countof(g_ServerIp));
            GetDlgItemText(hDlg, IDC_EDIT2, g_NickName, _countof(g_ServerIp));
            EndDialog(hDlg, NULL);
            return true;
        }
        break;
    }
    return false;
}