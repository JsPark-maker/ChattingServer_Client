﻿#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#include "framework.h"
#include "ChattingServer2.h"
#include "CRingBuffer.h"
#include "PacketDefine.h"

#define MAX_LOADSTRING 100
#define SERVERPORT 9000
#define WM_MESSAGE (WM_USER + 1)



HINSTANCE hInst;                                // 현재 인스턴스입니다.
WCHAR szTitle[MAX_LOADSTRING];                  // 제목 표시줄 텍스트입니다.
WCHAR szWindowClass[MAX_LOADSTRING];            // 기본 창 클래스 이름입니다.

ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);

HWND g_hWnd;
SOCKET g_ListenSock;
stCLIENT* g_ClientList;
int g_ClientID;

void AddSocket(SOCKET sock);
void CloseSocket(SOCKET sock);
void SendBroadCast(stCLIENT*, stHEADER*, char*);
void SendUniCast(stCLIENT*, stHEADER*, char*);
void ReadEvent(SOCKET sock);
void WriteEvent(stCLIENT*);
bool RecvDataAnalysis(stCLIENT*, stHEADER*, char*);//이 함수에서 데이터를 분석할것이다. 두번째인자는 리턴을 위함이다. 이 함수의 리턴값은 알맞게 데이터가 왔을 시 true 아니면 false다
void ConnectUserProc(stCLIENT*, stHEADER*, stPACKET_CONNECT_USER*);
void MessageProc(stCLIENT*, stHEADER*, stPACKET_MESSAGE*);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: 여기에 코드를 입력합니다.

    // 전역 문자열을 초기화합니다.
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_CHATTINGSERVER2, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // 애플리케이션 초기화를 수행합니다:
    if (!InitInstance (hInstance, nCmdShow))
    {
        return FALSE;
    }

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_CHATTINGSERVER2));

    MSG msg;

    g_ClientList = new stCLIENT;

    AllocConsole();///////////////////////////
    freopen("CONOUT$", "wt", stdout);///////// 콘솔띄워주는부분
    printf("서버가동\n");//////////////////

    int retVal;

    WSADATA wsa;

    WSAStartup(MAKEWORD(2, 2), &wsa);

    g_ListenSock = socket(AF_INET, SOCK_STREAM, NULL);

    WSAAsyncSelect(g_ListenSock, g_hWnd, WM_MESSAGE, FD_ACCEPT);

    SOCKADDR_IN serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);
    serverAddr.sin_port = htons(SERVERPORT);

    retVal = bind(g_ListenSock, (SOCKADDR*)&serverAddr, sizeof(serverAddr));
    if (retVal == SOCKET_ERROR)
    {
        printf("바인드 에러\n");
        return 1;
    }

    retVal = listen(g_ListenSock, SOMAXCONN);
    if (retVal == SOCKET_ERROR)
    {
        printf("리슨에러\n");
        return 1;
    }

    while (GetMessage(&msg, nullptr, 0, 0)) //메시지 없을경우에 블락
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg); //WndProc을 실제로 호출시키는 주체
        }
    }

    return (int) msg.wParam;
}

ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_CHATTINGSERVER2));
    wcex.hCursor        = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = MAKEINTRESOURCEW(IDC_CHATTINGSERVER2);
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // 인스턴스 핸들을 전역 변수에 저장합니다.

   g_hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      0, 0, 300, 300, nullptr, nullptr, hInstance, nullptr);

   if (!g_hWnd)
   {
      return FALSE;
   }

   ShowWindow(g_hWnd, nCmdShow);
   UpdateWindow(g_hWnd);

   return TRUE;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_MESSAGE:
        if (WSAGETSELECTERROR(lParam))
        {
            printf("WSAGETSELECTERROR CloseSocket을 호출합니다.\n");
            CloseSocket(wParam);
            break;
        }
        switch (WSAGETSELECTEVENT(lParam))
        {
        case FD_ACCEPT:
        {
            printf("클라이언트 접속\n");
            SOCKADDR_IN clientAddr;
            int size = sizeof(clientAddr);
            //두번째 세번째 인자 NULL로 바꿔보기
            SOCKET clientSock = accept(g_ListenSock, (SOCKADDR*)&clientAddr, &size);
            WSAAsyncSelect(clientSock, hWnd, WM_MESSAGE, FD_READ | FD_WRITE | FD_CLOSE);
            AddSocket(clientSock);
            
            for (stCLIENT* clientList = g_ClientList;; clientList = clientList->next)
            {
                if (clientList == nullptr)
                    break;

                if (clientList->sock != clientSock)
                    continue;

                stHEADER header;
                stPACKET_CLIENT_ID packet;
                header.type = dfPACKET_CLIENT_ID;
                header.len = sizeof(stPACKET_CLIENT_ID);
                packet.id = clientList->id;

                SendUniCast(clientList, &header, (char*)&packet);
            }

        }
            break;
        case FD_READ:
            printf("수신버퍼반응\n");
            ReadEvent(wParam); //소켓이 들어옴
            break;
        case FD_WRITE:
            for (stCLIENT* client = g_ClientList;;)
            {
                if (client->sock == wParam)
                {
                    WriteEvent(client);
                    break;
                }
                client = client->next;
            }
            break;
        case FD_CLOSE:
            printf("클라이언트가 연결해제를 시도했습니다.\n");
            CloseSocket(wParam);
            break;
        }
        break;
    case WM_COMMAND:
        {
            int wmId = LOWORD(wParam);
            // 메뉴 선택을 구문 분석합니다:
            switch (wmId)
            {
            case IDM_EXIT:
                DestroyWindow(hWnd);
                break;
            default:
                return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }
        break;
    case WM_PAINT:
        {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);
            // TODO: 여기에 hdc를 사용하는 그리기 코드를 추가합니다...
            EndPaint(hWnd, &ps);
        }
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

void AddSocket(SOCKET sock)
{
    for (stCLIENT* clientPtr = g_ClientList;;)
    {
        if(clientPtr->next == nullptr)//마지막 인덱스라는 의미
        {
            clientPtr->next = new stCLIENT;
            clientPtr->next->sock = sock;
            clientPtr->next->id = g_ClientID++;
            clientPtr->next->prev = clientPtr;
            break;
        }
        clientPtr = clientPtr->next;
    }
}

void CloseSocket(SOCKET sock)
{
    for (stCLIENT* clientPtr = g_ClientList->next;;)
    {
        if (clientPtr == nullptr)
            break;
        
        if (clientPtr->sock == sock)
        {
            closesocket(clientPtr->sock);
            
            if (clientPtr->next == nullptr)
            {
                clientPtr->prev->next = nullptr;
            }
            else
            {
                clientPtr->prev->next = clientPtr->next;
                clientPtr->next->prev = clientPtr->prev;
            }
            delete clientPtr;
            break;
        }
        clientPtr = clientPtr->next;
    }
}

//recv받아서 수신링버퍼에 인큐잉한다.
void ReadEvent(SOCKET sock)
{
    int recvBytes;
    int enqueueBytes;
    char packet[1000];

    for (stCLIENT* clientPtr = g_ClientList->next;;clientPtr = clientPtr->next)
    {
        if (clientPtr == nullptr)
            break;

        if (clientPtr->sock == sock)
        {
            recvBytes = recv(clientPtr->sock, packet, sizeof(packet), NULL);
            stHEADER* header = (stHEADER*)packet;

            if (recvBytes == SOCKET_ERROR)
            {
                if (WSAGetLastError() != WSAEWOULDBLOCK)
                {
                    printf("클라이언트와의 접속에서 문제가 발생했습니다.\n");
                    CloseSocket(sock);
                    return;
                }
            }

            if (recvBytes == 0)
            {
                printf("클라이언트가 접속을 종료했습니다\n");
                CloseSocket(sock);
                return;
            }
            
            printf("%d 바이트만큼 받았습니다.\n", recvBytes);
            //클라이언트의 수신링버퍼에 인큐잉한다.
            enqueueBytes = clientPtr->recvQueue.Enqueue(packet, recvBytes);

            if (recvBytes != enqueueBytes)
            {
                printf("ReadEvent에서 인큐가 되지 않았습니다. 이 클리아언트를 종료합니다.\n");
                CloseSocket(sock);
                return;
            }

            while (1)
            {
                stHEADER header;
                char packet[1000];
                int test;

                if (clientPtr->recvQueue.GetUseSize() < sizeof(header))
                {
                    //헤더만큼도 없다.
                    return;
                }
                clientPtr->recvQueue.Peek((char*)&test, sizeof(test));
                clientPtr->recvQueue.Peek((char*)&header, sizeof(header));

                if (clientPtr->recvQueue.GetUseSize() < header.len + sizeof(header))
                {
                    printf("헤더는 왔지만 데이터가 안왔습니다.\n");
                    return;
                }

                clientPtr->recvQueue.MoveFront(sizeof(header));
                clientPtr->recvQueue.Dequeue(packet, header.len);

                switch (header.type)
                {
                case dfPACKET_CONNECT_USER:
                    ConnectUserProc(clientPtr, &header, (stPACKET_CONNECT_USER*)packet);
                    break;
                case dfPACKET_MESSAGE:
                    MessageProc(clientPtr, &header, (stPACKET_MESSAGE*)packet);
                    break;
                }
            }

        }
    }
}

void WriteEvent(stCLIENT* client)
{
    int dequeueBytes;
    int sendBytes;
    char buffer[1000];

    while (1)
    {
        if (client->sendQueue.GetUseSize() == 0)
            break;

        dequeueBytes = client->sendQueue.Peek(buffer, 1000);

        sendBytes = send(client->sock, buffer, dequeueBytes, NULL);

        if (sendBytes == SOCKET_ERROR)
        {
            if (WSAGetLastError() == WSAEWOULDBLOCK)
            {
                client->sendQueue.MoveFront(sendBytes);
                return;
            }
            else
            {
                printf("WriteEvent에서 send하는데 문제가 발생했습니다 소켓을 닫습니다.\n");
                CloseSocket(client->sock);
                return;
            }
        }

        client->sendQueue.MoveFront(sendBytes);
    }
}

bool RecvDataAnalysis(stCLIENT* clientPtr, stHEADER* header, char* data)
{
    if (clientPtr->recvQueue.GetUseSize() < sizeof(header))
    {
        printf("RecvDataAnalysis함수에서 받은 데이터가 헤더크기조차없어 리턴합니다.\n");
        return false;
    }

    clientPtr->recvQueue.Peek((char*)header, sizeof(header));

    if (clientPtr->recvQueue.GetUseSize() < header->len + sizeof(header))
    {
        printf("RecvDataAnalysis함수에서 페이로드가 완성되지않아 리턴합니다.\n");
        return false;
    }

    clientPtr->recvQueue.MoveFront(sizeof(header));
    clientPtr->recvQueue.Dequeue(data, header->len);

    return true;
}

void ConnectUserProc(stCLIENT* clientPtr, stHEADER* header, stPACKET_CONNECT_USER* packet)
{
    wcscpy(clientPtr->nick, packet->myNickName);
    stHEADER clientHeader;
    stPACKET_CREATE_USER createPacket;

    clientHeader.type = dfPACKET_CREATE_USER;
    clientHeader.len = wcslen(clientPtr->nick) * 2 + sizeof(WCHAR) + sizeof(createPacket.id);
    createPacket.id = clientPtr->id;

    wcscpy(createPacket.userNickName, clientPtr->nick);

    SendBroadCast(clientPtr, &clientHeader, (char*)&createPacket);

    for (stCLIENT* clientList = g_ClientList->next;; clientList = clientList->next)
    {
        if (clientList == nullptr)
            break;

        if (clientList->id == clientPtr->id)
            continue;

        clientHeader.len = wcslen(clientList->nick) * 2 + sizeof(WCHAR) + sizeof(createPacket.id);
        createPacket.id = clientList->id;
        wcscpy(createPacket.userNickName, clientList->nick);
        //wprintf(L"ADFASDFASDFASDF -> %s\n", createPacket2.userNickName);
        SendUniCast(clientPtr, &clientHeader, (char*)&createPacket);
    }
}

void MessageProc(stCLIENT* clientPtr, stHEADER* header, stPACKET_MESSAGE* packet)
{
    stHEADER clientHeader;
    clientHeader.type = dfPACKET_MESSAGE;
    clientHeader.len = header->len;

    SendBroadCast(clientPtr, &clientHeader, (char*)packet);
}

void SendBroadCast(stCLIENT* clientPtr, stHEADER* headerPtr, char* packetPtr)
{
    int enqueueBytes;

    for (stCLIENT* clientList = g_ClientList->next;; clientList = clientList->next)
    {
        if (clientList == nullptr)
            break;

        enqueueBytes = clientList->sendQueue.Enqueue((char*)headerPtr, sizeof(stHEADER));
        if (enqueueBytes != sizeof(stHEADER))
        {
            printf("SendBroadCast함수에서 데이터가 인큐되지않았습니다. 해당 소켓을 종료합니다.\n");
            stCLIENT* clientListBuffer = clientList->next;
            CloseSocket(clientList->sock);
            clientList = clientListBuffer;
            continue;
        }

        enqueueBytes = clientList->sendQueue.Enqueue((char*)packetPtr, headerPtr->len);
        if (enqueueBytes != headerPtr->len)
        {
            printf("SendBroadCast함수에서 데이터가 인큐되지않았습니다. 해당 소켓을 종료합니다.\n");
            stCLIENT* clientListBuffer = clientList->next;
            CloseSocket(clientList->sock);
            clientList = clientListBuffer;
            continue;
        }
        //여기까지왔으면 모든 데이터가 송신버퍼에 인큐됬다.

        WriteEvent(clientList);
    }
}

void SendUniCast(stCLIENT* clientPtr, stHEADER* headerPtr, char* packet)
{
    int enqueueBytes;

    enqueueBytes = clientPtr->sendQueue.Enqueue((char*)headerPtr, sizeof(stHEADER));

    if (enqueueBytes != sizeof(stHEADER))
    {
        printf("SendUniCast함수에서 인큐되지않았습니다. 해당소켓을 종료합니다.\n");
        CloseSocket(clientPtr->sock);
        return;
    }

    enqueueBytes = clientPtr->sendQueue.Enqueue(packet, headerPtr->len);

    if (enqueueBytes != headerPtr->len)
    {
        printf("SendUniCast함수에서 인큐되지않았습니다. 해당소켓을 종료합니다.\n");
        CloseSocket(clientPtr->sock);
        return;
    }

    WriteEvent(clientPtr);
}