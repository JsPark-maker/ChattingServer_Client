#pragma once
#include <Windows.h>

#define dfPACKET_CREATE_USER     1//S -> C
#define dfPACKET_CONNECT_USER    2//C -> S
#define dfPACKET_MESSAGE         3//S -> C || C -> S
#define dfPACKET_DELETE_USER     4//S -> C
#define dfPACKET_CLIENT_ID       5//S -> C

struct stCLIENT
{
    int id;
    WCHAR nick[128];
    SOCKET sock;
    CRingBuffer recvQueue;
    CRingBuffer sendQueue;
    stCLIENT* next = nullptr;
    stCLIENT* prev = nullptr;
};

struct stHEADER
{
    int type;
    //�̰� ������ �ʿ���, ��? �ڿ� ��Ŷ�� �� �����ߴ��� �Ǵ��ؾ��ϱ� ����
    int len;
};

struct stPACKET_MESSAGE
{
    int id;
    WCHAR packet[128];
};

struct stPACKET_CONNECT_USER
{
    WCHAR myNickName[128];
};

struct stPACKET_CREATE_USER
{
    int id;
    WCHAR userNickName[128];
};

struct stPACKET_DELETE_USER
{
    int id;
};

struct stPACKET_CLIENT_ID
{
    int id;
};
